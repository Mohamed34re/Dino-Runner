
#include "HeaderFiles/Control.h"





int main()
{
	Control x;
	x.Run();
}
