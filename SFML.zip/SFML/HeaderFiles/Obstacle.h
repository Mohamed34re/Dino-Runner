//#include <iostream>
//#include <SFML/Graphics.hpp>
//#include <SFML/System.hpp>
//#include <SFML/Window.hpp>
//#include <SFML/Audio.hpp>
//#include <SFML/Network.hpp>
//#include <vector>
//#include "Menu.h"
//using namespace sf;
//using namespace std;
//
//
//
//
//
//class Obstacle
//{
//public:
//    Sprite obstacleSprite;
//    FloatRect obstacleBounds{ 0.f, 0.f, 0.f, 0.f };
//    Obstacle(Texture& texture) :obstacleSprite(), obstacleBounds()
//    {
//        obstacleSprite.setTexture(texture);
//        //obstacleSprite.setPosition(Vector2f(windowSize_x, groundOffset));
//    }
//};