//
//#include <iostream>
//#include <SFML/Graphics.hpp>
//#include <SFML/System.hpp>
//#include <SFML/Window.hpp>
//#include <SFML/Audio.hpp>
//#include <SFML/Network.hpp>
//#include <vector>
//#include "Menu.h"
//using namespace sf;
//using namespace std;
//
//
//
//
//class SoundManager
//{
//    Sound* duckSound;
//    Sound* jumpSound;
//    Sound* jump2Sound;
//    SoundBuffer* duckBuffer;
//    SoundBuffer* jumpBuffer;
//    SoundBuffer* jump2Buffer;
//public:
//
//
//    SoundManager();
//
//    void Start();
//};