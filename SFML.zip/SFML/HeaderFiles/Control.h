#pragma once
#include "GUI.h"

class Control
{
private:
	GUI* gUI;


public:
	Control();


	void Run();
};

